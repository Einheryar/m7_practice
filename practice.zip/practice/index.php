<?php
    $p = 'Приветствую Вас на моей страничке!';
?>

<?php
    $name = 'Сергей';
    $surname = 'Сорокин';
    $city = 'Красноярск';
    $age = 38;
?>

<?php   include 'main.php'  ?>

