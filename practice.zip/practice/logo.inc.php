<div class="logo">
    <img src="img/logo.jpg" alt="logo">
</div>