<nav>
    <ul>
        <li><a href="#">О моей учебе</a></li>
        <li><a href="#">Мое портфолио</a></li>
        <li><a href="#">Мои статьи</a></li>
        <li><a href="#">Ссылки</a></li>
        <li><a href="#">Контакты</a></li>
    </ul>
</nav>